/* -*- Mode: C++; c-basic-offset:4 ; -*- */
/*  
 *  (C) 2006 by Argonne National Laboratory.
 *      See COPYRIGHT in top-level directory.
 */
#include <iostream.h>
int main( int argc, char *argv[] )
{
    cout << testname;
    return 0;
}

#include <stdio.h>
#include <string>

#define NUM_ATT 7862
#define NUM_RECORDS 18
#define MAX_FIELD_LENGTH 1000
#define MAX_TRASH_LENGTH 1000

static bool getNextField (FILE * __f, char * __buff) {
  
  char trash [MAX_TRASH_LENGTH];  
      
  fscanf (__f, "%[ \t\n]", trash); /* Discarding sep. */ 
  fscanf (__f, "%[^,\n]", __buff); /* Reading the field */
  
  return fgetc (__f) == '\n';  
}

int main (int __argc, char * * __argv) {

  char buff [MAX_FIELD_LENGTH];

  std :: string t [NUM_RECORDS] [NUM_ATT];
  
  for (unsigned i = 0; i < NUM_RECORDS; i ++)
    
    for (unsigned j = 0; j < NUM_ATT; j ++) {
      
      getNextField (stdin, buff);
      t [i] [j] = buff;       
    }

  for (unsigned j = 0; j < NUM_ATT; j ++) {
  
    for (unsigned i = 0; i < NUM_RECORDS; i ++) {
         
      printf ("%s", t [i] [j].c_str ());
      if (i < NUM_RECORDS - 1)
	printf (", ");
      else
	printf ("\n");      
    }  
  }
}

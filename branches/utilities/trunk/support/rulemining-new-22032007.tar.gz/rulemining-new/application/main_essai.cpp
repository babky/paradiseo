// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "main_essai.cpp"

// (c) OPAC Team, LIFL, January 2006

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include <eoPop.h>
#include <apply.h>

/* Rule mining */
#include "param.h"
#include "pretty_print.h"

#include "rule_init.h"
#include "rule_eval.h"

#include "exch_insert_cross.h"
#include "rule_value_mut.h"
#include "data.h"

#define POP_SIZE 100

int main (int __argc, char * * __argv) {

  //  rng.reseed (1);

  loadParameters (__argc, __argv);
  //  printDatabase ();

  RuleInit init;

  RuleEval eval;

  Rule rule;
  init (rule);

  //  while (true) {
    
  eval (rule);
  prettyPrint (rule, std :: cout);
  std :: cout << rule.fitness () << std :: endl;
    //}

  /*
  eoPop <Rule> pop (POP_SIZE, init);
  apply (eval, pop);
  for (unsigned i = 0; i < POP_SIZE; i ++)
    std :: cout << pop [i].fitness () << std :: endl;
  */

  ExchangeInsertCross cross; /* Exchange / Insert crossover */  
  RuleValueMut mut; /* Combined mutator */
  /*  
  Rule father, mother;
  init (father);
  init (mother);
  eval (father);
  eval (mother);

  std :: cout << "Avant." << std :: endl;
  prettyPrint (father, std :: cout);
  std:: cout << father.fitness () << std :: endl; 
  prettyPrint (mother, std :: cout);
  std:: cout << mother.fitness () << std :: endl; 
  std :: cout << std :: endl;

  std :: cout << "Apres." << std :: endl;
  cross (father, mother);
  eval (father);
  eval (mother);
  prettyPrint (father, std :: cout);
  std:: cout << father.fitness () << std :: endl; 
  prettyPrint (mother, std :: cout);
  std:: cout << mother.fitness () << std :: endl; 
  std :: cout << std :: endl;
  */    
  return 0;
}

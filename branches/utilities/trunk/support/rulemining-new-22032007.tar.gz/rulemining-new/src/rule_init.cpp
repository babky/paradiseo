// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "rule_init.cpp"

// (c) OPAC Team, LIFL, January 2006

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
d   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include <utils/eoRNG.h>

#include "rule_init.h"
#include "mix.h"
#include "valid.h"

void RuleInit :: operator () (Rule & __rule) {

  __rule.clear ();

  /* Prediction */
  
  AttributeKey goal_attr = goal_attr_keys [rng.random (num_goal_attributes)];
  
  ValueKey goal_value = getRandomValueKey (goal_attr);

  __rule.push_back (Term (goal_attr, goal_value));

  /* Condition */
  
  unsigned num_terms = 2 + rng.random (max_terms - 1);
  
  std :: vector <AttributeKey> attr;
  
  for (unsigned i = 0; i < num_attributes; i ++)
    attr.push_back (i);  
  mix (attr);

  for (unsigned i = 0; i < num_attributes; i ++)
    if (attr [i] != goal_attr) {
      __rule.push_back (Term (attr [i], getRandomValueKey (attr [i])));
      if (__rule.size () == num_terms)
	break ;      
    }
  validate (__rule);
}

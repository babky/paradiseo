// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "data.cpp"

// (c) OPAC Team, LIFL, January 2006

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>

#include "data.h"
#include "attribute.h"
#include "param.h"

#define MAX_TRASH_LENGTH 1000
#define MAX_FIELD_LENGTH 1000
#define MAX_RECORDS 100000

std :: vector <Record> records; /* Set of records to mine */ 

unsigned num_records; /* Total number of records */ 

static bool getNextField (FILE * __f, char * __buff) {
  
  char trash [MAX_TRASH_LENGTH];  
      
  fscanf (__f, "%[ \t\n]", trash); /* Discarding sep. */ 
  fscanf (__f, "%[^,;\n]", __buff); /* Reading the field */
  
  return fgetc (__f) == '\n';  
}

void printDatabase () {
  
  for (unsigned i = 0; i < num_records; i ++) {
    
    for (unsigned j = 0; j < num_attributes; j ++)
      printf ("%u ", records [i].att_values [j]);
    
    printf ("\n");
  }
}

extern void loadDatabase (const char * __filename) {

  FILE * f = fopen (__filename, "r");

  if (f) {
     
    printf ("loading the database from '%s'.\n", __filename);

    char field [MAX_FIELD_LENGTH];

    num_records = 0;
    
    if (! reverse_data) {

      while (true) {
	
	Record rec;
	
	for (unsigned j = 0; j < num_attributes; j ++) {
	  
	  getNextField (f, field);
	  //	printf ("##%s\n", field);
	  rec.att_values [j] = getKeyFromValue (j, field); 
	}
	if (feof (f))
	  break;
	else {
	  records.push_back (rec);
	  num_records ++;
	}
      }
    }
    else {
      
      bool eol;

      std :: vector <ValueKey> values (MAX_RECORDS);
      do {
	
	eol = getNextField (f, field);
	values [num_records ++] = getKeyFromValue (0, field);
      
      } while (eol != '\n');

      
      records.resize (num_records);
      std :: cout << num_records << " enregistrements." << std :: endl;

      for (unsigned i = 0; i < num_records; i ++)
	records [i].att_values [0] = values [i];
      
      for (unsigned i = 1; i < num_attributes; i ++) {
	
	std :: cout << "Etape : " << i << std :: endl;

	for (unsigned j = 0; j < num_records; j ++) {
	  
	  getNextField (f, field);
	  records [j].att_values [i] = getKeyFromValue (i, field);
	}
      }
    }
    
    printf ("found %u records.\n", num_records);
  }
 else {
    
    fprintf (stderr, "can't open '%s'.\n", __filename); 
    exit (1);
  }
}




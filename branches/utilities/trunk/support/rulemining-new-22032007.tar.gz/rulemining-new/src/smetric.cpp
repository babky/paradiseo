// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "smetric.cpp"

// (c) OPAC Team, LIFL, January 2006

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

/*
  This code is part from the code of Eckart Zitzler
  Computer Engineering and Networks Laboratory(TIK)
  It can be found :
  ftp://ftp.tik.ee.ethz.ch/pub/people/zitzler/hypervol.c
 */

#include <assert.h>
#include <iostream>
#include <fstream>
#include <vector>

#include "smetric.h"
#include "converg.h"
#include "rule_eval.h"

#define ERROR 0
#define MAX_OBJ 1
#define MIN_OBJ 0

//unsigned NUM_FRONTS;
//unsigned num_fronts;

/* returns true if 'point1' dominates 'points2' with respect to the
   to the first 'noObjectives' objectives */
int  Dominates(double  point1[], double  point2[], unsigned num_obj2) {
  int  i;
  int  betterInAnyObjective;
  
  betterInAnyObjective = 0;
  for (i = 0; i < (int) num_obj2 && point1[i] >= point2[i]; i++)
    if (point1[i] > point2[i])
      betterInAnyObjective = 1;
  return (i >= (int) num_obj2 && betterInAnyObjective);
} /* Dominates */

void  Swap(double  *front[], int  i, int  j) {
  double  *temp;
  
  temp = front[i];
  front[i] = front[j];
  front[j] = temp;
} /* Swap */

/* all nondominated points regarding the first 'NUM_OBJ' dimensions
   are collected; the points referenced by 'front[0..noPoints-1]' are
   considered; 'front' is resorted, such that 'front[0..n-1]' contains
   the nondominated points; n is returned */
int  FilterNondominatedSet(double  *front[], int  noPoints, unsigned __num_obj) {
  int  i, j;
  int  n;
  
  n = noPoints;
  i = 0;
  while (i < n) {
    j = i + 1;
    while (j < n) {
      if (Dominates(front[i], front[j], __num_obj)) {
	/* remove point 'j' */
	n--;
	Swap(front, j, n);
      }
      else if (Dominates(front[j], front[i], __num_obj)) {
	/* remove point 'i'; ensure that the point copied to index 'i'
	   is considered in the next outer loop (thus, decrement i) */
	n--;
	Swap(front, i, n);
	i--;
	break;
      }
      else
	j++;
    }
    i++;
  }
  return n;
} /* FilterNondominatedSet */


/* calculate next value regarding dimension 'objective'; consider
   points referenced in 'front[0..noPoints-1]' */
double  SurfaceUnchangedTo(double  *front[], int  noPoints, int  objective) {
  int     i;
  double  minValue, value;
  
  //  if (noPoints < 1)  ERROR("run-time error");
  minValue = front[0][objective];
  for (i = 1; i < noPoints; i++) {
    value = front[i][objective];
    if (value < minValue)  minValue = value;
  }
  return minValue;
} /* SurfaceUnchangedTo */

/* remove all points which have a value <= 'threshold' regarding the
   dimension 'objective'; the points referenced by
   'front[0..noPoints-1]' are considered; 'front' is resorted, such that
   'front[0..n-1]' contains the remaining points; 'n' is returned */
int  ReduceNondominatedSet(double  *front[], int  noPoints, int  objective,
			   double  threshold) {
  int  n;
  int  i;
  
  n = noPoints;
  for (i = 0; i < n; i++)
    if (front[i][objective] <= threshold) {
      n--;
      Swap(front, i, n);
    }
  return n;
} /* ReduceNondominatedSet */

double  CalculateHypervolume(double  *front[], int  noPoints, unsigned num_obj2){
  int     n;
  double  volume, distance;
  
  volume = 0;
  distance = 0;
  n = noPoints;
  while (n > 0) {
    int     noNondominatedPoints;
    double  tempVolume, tempDistance;
    
    noNondominatedPoints = FilterNondominatedSet(front, n, num_obj2 - 1);
    tempVolume = 0;
    if (num_obj2 < 3) {
      //      if (noNondominatedPoints < 1)  ERROR("run-time error");
      tempVolume = front[0][0];
    }
    else
      tempVolume = CalculateHypervolume(front, noNondominatedPoints,
					num_obj2 - 1);
    tempDistance = SurfaceUnchangedTo(front, n, num_obj2 - 1);  
    volume += tempVolume * (tempDistance - distance);
    distance = tempDistance;
    n = ReduceNondominatedSet(front, n, num_obj2 - 1, distance);
  }
  //  std :: cout << "volume = " << volume << std :: endl;
  return volume;
}

/* CalculateHypervolume */

/*
int  MergeFronts(double  **frontPtr[], double  *front1[], int  sizeFront1,
		 double*  front2[], int  sizeFront2) {
  int  i, j;
  int  noPoints;
  
  noPoints = sizeFront1 + sizeFront2;
  *frontPtr = (double**)malloc(noPoints * sizeof(double *));
  //  if (*frontPtr == NULL)  ERROR("memory allocation failed");
  for (i = 0; i < noPoints; i++) {
    (*frontPtr)[i] = (double*)malloc(NUM_OBJ * sizeof(double));
    //if ((*frontPtr)[i] == NULL)  ERROR("memory allocation failed");
  }
 
  noPoints = 0;
  for (i = 0; i < sizeFront1; i++) {
    for (j = 0; j < NUM_OBJ; j++)
      (*frontPtr)[noPoints][j] = front1[i][j];
    noPoints++;
  }
  for (i = 0; i < sizeFront2; i++) {
    for (j = 0; j < NUM_OBJ; j++)
      (*frontPtr)[noPoints][j] = front2[i][j];
    noPoints++;
  }
  
  return noPoints;
}
*/
void  DeallocateFront(double**  front, int  noPoints) {
  int  i;
  
  if (front != NULL) {
    for (i = 0; i < noPoints; i++)
      if (front[i] != NULL)
	free(front[i]);
    free(front);
  }
} /* DeallocateFront */



void ReadFront(double **** fronts, unsigned int **size, std :: vector <std :: vector <MOS> > & __v, std :: vector <bool> & __obj_aims, unsigned __num_fronts) {
  
  (*fronts) = new double**[__num_fronts];
  (*size) = new unsigned int[__num_fronts];

  for(unsigned int i = 0; i < __num_fronts; i++) {
    (*size)[i] = __v [i].size();
    (*fronts)[i] = new double*[(*size)[i]];
    for(unsigned int j = 0; j < (*size)[i]; j++) {
      (*fronts)[i][j] = new double[num_crit];
      for(unsigned int k = 0; k < num_crit; k++) {  
	(*fronts)[i][j][k] = __v [i][j][k];
      }
    }
  }
  
  for(unsigned int k = 0; k < num_crit; k++)  // Pour chaque objectif
    if(__obj_aims[k] == MAX_OBJ) { // Si on maximise
      double min = (*fronts)[0][0][k]; // minimum de l'objectif
      for(unsigned int i = 0; i < __num_fronts; i++) 
	for(unsigned int j = 0; j < (*size)[i]; j++) 
	  if(min > (*fronts)[i][j][k])
	    min = (*fronts)[i][j][k];
      for(unsigned int i = 0; i < __num_fronts; i++) 
	for(unsigned int j = 0; j < (*size)[i]; j++) 
	  (*fronts)[i][j][k] -= min;
    } else { // Si on minimise
      double max = (*fronts)[0][0][k]; // minimum de l'objectif
      for(unsigned int i = 0; i < __num_fronts; i++) 
	for(unsigned int j = 0; j < (*size)[i]; j++) 
	  if(max < (*fronts)[i][j][k])
	    max = (*fronts)[i][j][k];
      for(unsigned int i = 0; i < __num_fronts; i++) 
	for(unsigned int j = 0; j < (*size)[i]; j++) { 
	  (*fronts)[i][j][k] -=  max;
	  (*fronts)[i][j][k] *= -1;
	}
    }
}

SmetricUpdater :: SmetricUpdater (moeoArchive <Rule> & __arch,
				  int __rank
				  ) : arch (__arch),
				      rank (__rank) {

}

void SmetricUpdater :: operator () () {

  std :: vector <MOS> f;
  
  //
  for (unsigned i = 0; i < arch.size (); i ++) {
    
    MOS sol;
    for (unsigned j = 0; j < arch [i].fitness ().size (); j ++)
      sol.push_back (arch [i].fitness () [j]);
    f.push_back (sol);
  }
  list_fronts.push_back (f);
  //

  double *** fronts;
  unsigned int *size;
  double * volume = new double[list_fronts.size ()];
  
  std :: vector <bool> obj_aims (num_crit, true);

  ReadFront(&fronts, &size, list_fronts, obj_aims, list_fronts.size ());

  char filename [1000];
  
  if (rank == -1)
    sprintf (filename, "./res/smetric");
  else
    sprintf (filename, "./res/smetric.%d", rank);
  
  std :: ofstream of (filename);
    
  for(unsigned i = 0; i < list_fronts.size (); i++) {

    size[i] = FilterNondominatedSet(fronts[i], size[i], num_crit);
    //std :: cout << " size " << size [i] << std :: endl;
    volume[i] = CalculateHypervolume(fronts[i], size[i], num_crit);
    of << volume[i] << std :: endl ;    
  }
  of.close ();
  
}

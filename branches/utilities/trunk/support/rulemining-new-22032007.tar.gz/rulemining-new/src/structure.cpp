// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "structure.cpp"

// (c) OPAC Team, LIFL, January 2006

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <string.h>

#include "structure.h"
#include "attribute.h"
#include "data.h"

#define MAX_TRASH_LENGTH 1000
#define MAX_FIELD_LENGTH 1000

static bool getNextField (FILE * __f, char * __buff) {
  
  char trash [MAX_TRASH_LENGTH];  
      
  fscanf (__f, "%[ \t\n]", trash); /* Discarding sep. */ 
  fscanf (__f, "%[^,.:\n]", __buff); /* Reading the field */
  
  return fgetc (__f) == '\n';  
}

static void loadAttributes (FILE * __f) {

  char field [MAX_FIELD_LENGTH];

  getNextField (__f, field); /* Number of attributes */
  assert (! strcasecmp (field, "Number of attributes"));
  getNextField (__f, field);
  num_attributes = atoi (field); 
  printf ("dealing with %u attributes.\n", num_attributes);

  getNextField (__f, field); /* Attributes values*/
  assert (! strcasecmp (field, "Attributes"));
  
  for (unsigned i = 0; i < num_attributes; i ++) {

    std :: string name;
    std :: vector <std :: string> values;
    bool eol;

    getNextField (__f, field); /* Name */
    name = field;

    /* Values */
    do {
           
      eol = getNextField (__f, field); /* Attribute */
      values.push_back (field);
    } while (! eol);
    
    attributes.push_back (Attribute (name, values));
  }
}

static void loadGoalAttributes (FILE * __f) {

  char field [MAX_FIELD_LENGTH];

  //  bool eol; /* End of line */
 
  num_goal_attributes = 0;

  printf ("reading the goal attributes.\n");

  getNextField (__f, field); /* Goal attributes */
  
  /* Goal attributes */
  getNextField (__f, field);
    
  if (! strcasecmp (field, "all")) {
    num_goal_attributes = num_attributes;
    for (unsigned i = 0; i < num_attributes; i ++)
      goal_attr_keys.push_back (i);
  }    
  else {
    goal_attr_keys.push_back (getKeyFromAttribute (field));
    num_goal_attributes ++;
  }
}

void loadStructure (const char * __filename) {

  FILE * f = fopen (__filename, "r");

  if (f) {
     
    printf ("loading the structure of the structure from '%s'.\n", __filename);

    char field [MAX_FIELD_LENGTH];
       
    getNextField (f, field); /* Title */
    assert (! strcasecmp (field, "Title"));
    getNextField (f, field); 
    printf ("dealing with '%s'.\n", field);
    
    loadAttributes (f);

    buildAttributeKeys ();
    loadGoalAttributes (f);

    /*
    exit (1);    
    getNextField (f, field); 
    assert (! strcasecmp (field, "Number of Instances"));
    getNextField (f, field);
    num_records = atoi (field);
    */
  }
  else {
    
    fprintf (stderr, "Can't open '%s'.\n", __filename); 
    exit (1);
  }
}




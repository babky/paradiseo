// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "exch_insert_cross.cpp"

// (c) OPAC Team, LIFL, January 2006

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include "exch_insert_cross.h"
#include "valid.h"

static void findCommonAttributes (Rule & __father, Rule & __mother, std :: vector <AttributeKey> & __common_attr) {
  
  __common_attr.clear ();
  
  for (unsigned i = 1; i < __father.size (); i ++)
    for (unsigned j = 1; j < __mother.size (); j ++)
      if (ATTRIBUTE_KEY(__father [i]) == ATTRIBUTE_KEY(__mother [j]))
	__common_attr.push_back (ATTRIBUTE_KEY(__father [i]));
}

/* If two individuals X and Y have one or several common attribute(s) in the C parts,
   one common attribute is randomly selected. The value of the selected attribute in X
   is exchanged with its counterpart in Y */ 

static void exchange (Rule & __father, Rule & __mother, const std :: vector <AttributeKey> & __common_attr) {

  //  std :: cout << "Exchange" << std :: endl;

  AttributeKey attr = __common_attr [rng.random (__common_attr.size ())];

  unsigned i = 1, j = 1;
  
  while (ATTRIBUTE_KEY(__father [i]) != attr)
    i ++;
  while (ATTRIBUTE_KEY(__mother [j]) != attr)
    j ++;
  std :: swap (VALUE_KEY(__father [i]), VALUE_KEY(__mother [j])); 
}

/* If X and Y have no common attribute, one term is randomly selected in the C part
   of X, and inserted in Y with a probability inversely proportional to the 
   length of Y. */

static void insert (Rule & __father, Rule & __mother, Rule & __child) {

  __child = __mother;
    
  std :: vector <Term> cand_terms;

  for (unsigned i = 0; i < __father.size (); i ++) {
    
    bool ok = true;

    for (unsigned j = 0; j < __mother.size (); j ++)
      
      if (ATTRIBUTE_KEY(__mother [j]) == ATTRIBUTE_KEY(__father [i])) {
	ok = false;
	break;
      }
    if (ok)
      cand_terms.push_back (__father [i]);
  }

  if (! cand_terms.empty ()) {

    const Term & __term = cand_terms [rng.random (cand_terms.size ())];
    //std :: cout << "Chance : " << (1 - (double) __child.size () / max_terms) << std :: endl;
    if (rng.uniform () < (1 - (double) __child.size () / max_terms)) {
      ;//std :: cout << "Yeah !" << std :: endl;
      __child.push_back (__term);      
    }
    else
      ;//      std :: cout << "Nooo !" << std :: endl;
  }
}

static void insert (Rule & __father, Rule & __mother) {
 
  //  std :: cout << "Insert" << std :: endl;
 
  Rule f = __father, m = __mother;
  
  insert (f, m, __father);
  
  insert (m, f, __mother);
}

bool ExchangeInsertCross :: operator () (Rule & __father, Rule & __mother) {

  std :: vector <AttributeKey> common_attr;
  
  findCommonAttributes (__father, __mother, common_attr);
  
  if (common_attr.size ())
    exchange (__father, __mother, common_attr);
  else
    insert (__father, __mother);

  validate (__father);
  validate (__mother);

  return true;
}


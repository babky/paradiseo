
// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "rule.cpp"

// (c) OPAC Team, LIFL, January 2006

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include "rule.h"

unsigned max_terms = 5;

void Rule :: printOn (std :: ostream & __os) const {
  
  
}

void Rule :: readFrom (std :: istream & __is) {

}

bool Rule :: operator == (const Rule & __rule) const {

  if (size () != __rule.size ())
    return false;

  /* Prediction */
  
  if (__rule.front () != front ())
    return false;
  
  /* Condition */
  std :: vector <ValueKey> v1 (num_attributes, 0), v2 = v1;
  
  for (unsigned i = 0; i < size (); i ++)
    v1 [ATTRIBUTE_KEY(operator [] (i))] = VALUE_KEY(operator [] (i));
  
  for (unsigned i = 0; i < __rule.size (); i ++)
    v2 [ATTRIBUTE_KEY(__rule [i])] = VALUE_KEY(__rule [i]);

  for (unsigned i = 0; i < num_attributes; i ++)
    if (v1 [i] != v2 [i])
      return false;

  return true;
}

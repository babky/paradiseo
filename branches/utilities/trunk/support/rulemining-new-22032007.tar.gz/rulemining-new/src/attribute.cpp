// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "attribute.cpp"

// (c) OPAC Team, LIFL, January 2006

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include <map>

#include <utils/eoRNG.h>

#include "attribute.h"

unsigned num_attributes;

std :: vector <Attribute> attributes; 

unsigned num_goal_attributes; 

std :: vector <unsigned> goal_attr_keys;

static std :: map <std :: string, unsigned> attr_name_keys;

static std :: vector <std :: map <std :: string, unsigned> > attr_value_keys;

Attribute :: Attribute (const std :: string & __name,
			const std :: vector <std :: string> & __values
			) : name (__name),
			    values (__values) {

  num_values = values.size ();
}

void buildAttributeKeys () {

  attr_value_keys.resize (num_attributes);
  
  for (unsigned i = 0; i < num_attributes; i ++) {
    
    attr_name_keys [attributes [i].name] = i;

    const std :: vector <std :: string> & values = attributes [i].values;
    
    for (unsigned j = 0; j < values.size (); j ++)
      
      attr_value_keys [i] [values [j]] = j;
  }
}

AttributeKey getKeyFromAttribute (const char * __value) {

  return attr_name_keys [__value];
}

ValueKey getKeyFromValue (AttributeKey __att_key, const char * __value) {

  unsigned k = attr_value_keys [__att_key] [__value];
    
  return k;
}

const std :: string & getAttributeFromKey (AttributeKey __key) {
  
  return attributes [__key].name;
}

const std :: string & getValueFromKey (AttributeKey __num_att, ValueKey __key) {
  
  return attributes [__num_att].values [__key]; 
}

ValueKey getRandomValueKey (AttributeKey __num_att) {
  
  return rng.random (attributes [__num_att].num_values);
}

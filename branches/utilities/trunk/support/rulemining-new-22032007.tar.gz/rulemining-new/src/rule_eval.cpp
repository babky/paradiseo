// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "rule_eval.cpp"

// (c) OPAC Team, LIFL, January 2006

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include "rule_eval.h"
#include "data.h"

#include "support.h"
#include "confidence.h"
#include "jmeasure.h"
#include "interest.h"
#include "surprise.h"
#include "valid.h"

#define MAX_TRASH_LENGTH 1000
#define MAX_FIELD_LENGTH 1000

static std :: vector <double (*) (const Rule &)> measure; 

std :: vector <std ::string > selected_labels;

unsigned num_crit; /* Number of criterion */

RuleEval :: RuleEval () {

  std :: vector <bool> aims (num_crit, true);
  eoVariableParetoTraits :: setUp (num_crit, aims) ;
   
  //  std :: cout << measure.size () << "F.O." << std :: endl;
}

static bool right (const Term & __term, const Record & __rec) {

  return __rec.att_values [ATTRIBUTE_KEY(__term)] == VALUE_KEY(__term);
}

static bool rightPrediction (const Rule & __rule, const Record & __rec) {
  
  return right (__rule.front (), __rec);
}

static bool rightCondition (const Rule & __rule, const Record & __rec) {

  for (unsigned i = 1; i < __rule.size (); i ++)
    if (! right (__rule [i], __rec))      
      return false;

  return true;
}

void RuleEval :: operator () (Rule & __rule) {

  validate (__rule);
  
  /* Preprocessing */

  __rule.C = __rule.P = __rule.C_and_P = __rule.C_and_noP = 0;

  for (unsigned i = 0; i < num_records; i ++) {
    
    /* P */
    bool P = rightPrediction (__rule, records [i]);
    
    /* C */
    bool C = rightCondition (__rule, records [i]);
  
    if (P)
      __rule.P ++;
    if (C)
      __rule.C ++;
    if (C && P)
      __rule.C_and_P ++;
    if (C && ! P)
      __rule.C_and_noP ++;
  }
  /*

  std :: cout << "P = " <<__rule.P << std :: endl;
  std :: cout << "C = " <<__rule.C << std :: endl;
  std :: cout << "C & P = " <<__rule.C_and_P << std :: endl;
  std :: cout << "C & ! PP = " <<__rule.C_and_noP << std :: endl;
   */
  /* Objectives */

  RuleFit fit;
  for (unsigned i = 0; i < num_crit; i ++)
    fit [i] = measure [i] (__rule);
  //std :: cout << "Hehehe2" << std :: endl;
  __rule.fitness (fit);
  //  exit (1);
}

static char * getNextField (char * __from, char * __to) {
  
  char trash [MAX_TRASH_LENGTH];  

  char * t = __from; 

  bzero (trash, MAX_TRASH_LENGTH);
  bzero (__to, MAX_FIELD_LENGTH);
  
  sscanf (__from, "%[ \t\n]", trash); /* Discarding sep. */ 
  t += strlen (trash);
  
  sscanf (t, "%[^-\n]", __to); /* Reading the field */

  if (! strlen (__to))
    return 0;

  //  printf ("to = #%s#\n", __to);
  t += strlen (__to);
  
  //printf ("next =  #%c#\n", * t);

  return t;
}

void buildEvalModel (const std :: string & __list_obj) {

  char buff [MAX_FIELD_LENGTH];
  
  char * ptr = (char *) __list_obj.c_str ();

  num_crit = 0;
  
  do {

    if (! (ptr = getNextField (ptr, buff)))
      break;

    selected_labels.push_back (buff);
    num_crit ++;
    
    if (! strcasecmp (buff, "support")) {
      measure.push_back (support);
      printf ("adding support.\n");
    }
    else if (! strcasecmp (buff, "confidence")) {
      measure.push_back (confidence);
      printf ("adding confidence.\n");
    }
    else if (! strcasecmp (buff, "jmeasure")) {
      measure.push_back (jmeasure);
      printf ("adding jmeasure.\n");
    }
    else if (! strcasecmp (buff, "interest")) {
      measure.push_back (interest);
      printf ("adding interest.\n");
    }
    else if (! strcasecmp (buff, "surprise")) {
      measure.push_back (surprise);
      printf ("adding surprise.\n");
    }
    else {
      printf ("found an unknown metric for evaluation.\n");
      exit(1);
    }
    if (* ptr != '\n')
      ptr ++;

  } while (true);
  
  //  exit (1);
}

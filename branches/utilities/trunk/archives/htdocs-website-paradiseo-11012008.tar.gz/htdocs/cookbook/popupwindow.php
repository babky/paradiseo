<?php if (!defined('PmWiki')) exit();
    /* popupwindow.php, a module written for pmwiki 2
    for creating popup windows.
    copyright 2007 Hans Bracker.
    
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published
    by the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
    
    Simple syntax: %popwin%[[Group/PageName]] or %popwin%[[Group/PageName| Title]]
    Syntax with some parameters: %popwin height=300 width=400 top=20 left=20%[[link]]
    See list of available parameters below under $defaults
    For multiple popup-window links, each with some different parameters, 
    add id= parameter, for instance id=1, id=2 etc. 
    
    Additional markup:
    (:popclose Close Window:) creates a link for closing the popup window, 
    replace "Close Window" with whatever label text.
    add ?action=popopen to the %popwin%link
        %popwin%[[PageName?action=popopen| link text]]    
    opens the popup and sets a page variable {$PopOpen}. 
    Use it in the popup page in conditionals to trim side menus etc:
    (:if equal {$PopOpen} 1:)(:noleft:)(:popclose Close Window:)(:ifend:)
    */
$RecipeInfo['PopupWindow']['Version'] = '2007-03-20';

Markup('popwin1','<links','/%popwin\\s*(.*?)%\\[\\[(.*?)\\]\\]/e',
  "PopupWindow(\$pagename, PSS('$1'), PSS('$2'),NULL,'')");
 
Markup('popwin2','<popwin1',
  "/%popwin\\s*(.*?)%(?>\\[\\[([^|\\]]*)\\|\\s*)(.*?)\\s*\\]\\]($SuffixPattern)/e",
  "PopupWindow(\$pagename,PSS('$1'),PSS('$2'),PSS('$3'),'$4')"); 

function PopupWindow ($pagename, $opts, $tgt, $lbl, $sfx) {
   global $HTMLHeaderFmt,$LinkPopupFmt;
   $defaults = array(
      'id' => '0',
      'width' => 500,
      'height' => 300,
      'left' => 'center',
      'top' => 'center',      
      'resizable' => 1,
      'scrollbars' => 1,
      'toolbar' => 0,
      'location' => 0,
      'directories' => 0,
      'statusbar' => 0, 
      'menubar' => 0,
      );
   $opt = array_merge($defaults, ParseArgs($opts));
   
   $LinkPopupFmt = "<a href='\$LinkUrl' onclick=\"return popWin('\$LinkUrl','popup".$opt['id'].
                "','".$opt['width']."','".$opt['height']."','".$opt['left']."','".$opt['top'].
                "','".$opt['resizable']."','".$opt['scrollbars']."','".$opt['toolbar'].
                "','".$opt['location']."','".$opt['directories']."','".$opt['statusbar'].
                "','".$opt['menubar']."')\">\$LinkText</a>";
   
   $HTMLHeaderFmt['popwin'] = "
    <script language='javascript' type='text/javascript'><!--
      function popWin(url,id,px,py,pl,pt,rs,sb,tb,lo,di,st,mb) {
      if(pl=='center') var pl = (screen.width-px)/2;
      if(pt=='center') var pt = (screen.height-py)/2;
      newwindow=window.open(url,id,'toolbar='+tb+',scrollbars='+sb+',location='+lo+',statusbar='+st+',menubar='+mb+',directories='+di+',resizable='+rs+',width='+px+',height='+py+',left='+pl+',top='+pt+'');
         if (window.focus) {newwindow.focus()}
         return false;
     } // -->
    </script> \n";
   return Keep(MakeLink($pagename,$tgt,$lbl,$sfx,$GLOBALS['LinkPopupFmt']),'L');
}

# set PV {$PopOpen} with action=popopen
$HandleActions['popopen'] = 'PopOpenHandle';
function PopOpenHandle($pagename) {
    global $FmtPV;
    $FmtPV['$PopOpen'] = '"1"';
    HandleBrowse($pagename);
}

# create link for closing popup with (:popclose Close Window:)
Markup('popclose','directives','/\\(:popclose\\s*(.*?):\\)/e', 
       "Keep('<a href=\"$PageUrl?action=popclose\" onclick=\"self.close()\">$1</a>')");


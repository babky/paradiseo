<?php if (!defined('PmWiki')) exit();

/*
  PmWiki module for mail forms.
  Copyright (C) 2005 Joachim Durchholz (jo@durchholz.org).
  This code is licensed under the
  GNU General Public License version 2.0
  as distributed with PmWiki.
*/

define('MAILFORM2_VERSION', '0.91');

//require_once('cookbook/input.php');

SDV($Mailform2Recipient, '');
SDV($Mailform2Sender, '');
SDV($Mailform2Subject, '');
SDV($Mailform2Text, '');
SDV($Mailform2SuccessPage, 'Main.MailSentSuccessfully');
SDV($Mailform2FailurePage, 'Main.MailSendFailure');
SDV($Mailform2Disabled, 0);

SDV($HandleActions['mailform2'], 'Mailform2Handler');

function Mailform2Sanitise($str) {
  return preg_replace ('[\\0-\\37]', '', $str);
}

function Mailform2Handler($pagename) {
  global $Mailform2Recipient, $Mailform2Sender;
  global $Mailform2Subject, $Mailform2Text;
  global $Mailform2SuccessPage, $Mailform2FailurePage;
  global $Mailform2Disabled;
  $success = 0;
  if (!$Mailform2Disabled) {
    if (
      $Mailform2Recipient != ''
      && ($Mailform2Subject != '' || $Mailform2Text != '')
    ){
      $success =
        mail(
          Mailform2Sanitise($Mailform2Recipient),
          Mailform2Sanitise($Mailform2Subject),
          $Mailform2Text,
          'From:' . Mailform2Sanitise($Mailform2Sender)
        );
    }
  }
  if ($success) {
    Redirect($Mailform2SuccessPage);
  } else {
    Redirect($Mailform2FailurePage);
  }
}




// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

//-----------------------------------------------------------------------------
// moeoEpsilonDominanceObjectiveVectorComparator.h
// (c) OPAC Team (LIFL), Dolphin Project (INRIA), 2007
/*
    This library is intended to implement epsilon dominance

    Contact: paradiseo-help@lists.gforge.inria.fr, http://paradiseo.gforge.inria.fr
    Author: Emilia Tantar
 */
//-----------------------------------------------------------------------------

#ifndef MOEOEPSILONDOMINANCEOBJECTIVEVECTORCOMPARATOR_H_
#define MOEOEPSILONDOMINANCEOBJECTIVEVECTORCOMPARATOR_H_

#include <comparator/moeoObjectiveVectorComparator.h>
#include <vector>

using namespace std;

/**
 * This functor class allows to compare 2 objective vectors according to epsilon_dominance
 * The concept of epsilon-dominance is used for algorithms involving performance guarantee factors.
 */
template < class ObjectiveVector >
class moeoEpsilonDominanceObjectiveVectorComparator : public moeoObjectiveVectorComparator < ObjectiveVector >
{
public:

    /**
     * Constructor.
     * @param _epsilon represents the vector of epsilon values implied
     */
    moeoEpsilonDominanceObjectiveVectorComparator(const vector <double> & _iniEpsilon) {
	
	/*The default number of objectives is considered to be 2*/
	if(( ObjectiveVector::nObjectives() == 0 ) || ( ObjectiveVector::nObjectives() > 30 )){
		 cout<<"The specified number of objectives is zero or greater than 30"<<endl; 
		exit(0);
	}
	
	Epsilon.resize(ObjectiveVector::nObjectives());	

	/* If there are no values specified for epsilon it will be considered as the classical Pareto dominance relation*/
	if ( _iniEpsilon.size() == 0){

		for( int Index = 0; Index < Epsilon.size(); Index++ ) { Epsilon[ Index ] = 0; }

	}else if(_iniEpsilon.size() == ObjectiveVector::nObjectives()){
		
		for( int Index = 0; Index < Epsilon.size(); Index++ ){ Epsilon[ Index ] = _iniEpsilon[ Index ]; }

	}else if(_iniEpsilon.size() < ObjectiveVector::nObjectives()){
		
		for( int Index = _iniEpsilon.size(); Index < Epsilon.size(); Index++){ Epsilon[ Index ] = 0; }
	
	}else if(_iniEpsilon.size() > ObjectiveVector::nObjectives()){

		cout<<"The DIMMENSION of the Epsilon vector specified exceeds the number of objective functions! "<<endl;
		exit(0);
	}

	
   }

    /**
     * Returns true if _objectiveVector1 is epsilon-dominated by _objectiveVector2.
     * @param _objectiveVector1 the first objective vector
     * @param _objectiveVector2 the second objective vector
     */
    const bool operator()(const ObjectiveVector & _objectiveVector1, const ObjectiveVector & _objectiveVector2)
    {
	for(int Index = 0; Index < ObjectiveVector::nObjectives(); Index ++ ){
		
		if ( ObjectiveVector::minimizing( Index) ){		
			if( ( _objectiveVector1[ Index ] - _objectiveVector2[ Index ]) > Epsilon [ Index] ){
				return false;
			}
	
		}else if (ObjectiveVector::maximizing(Index)){

			if( ( _objectiveVector2[ Index ] - _objectiveVector1[ Index ]) > Epsilon [ Index ]){
				return false;
			}
		}
	}
			
	return true;
    }


private:

    /** the Epsilon vector*/
    vector <double> Epsilon;
};

#endif /*MOEOEPSILONDOMINANCEOBJECTIVEVECTORCOMPARATOR_H_*/

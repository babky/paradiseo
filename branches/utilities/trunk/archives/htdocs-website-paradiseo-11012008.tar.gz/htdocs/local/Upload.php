<?php $Skin = 'abitmodern';?>

<?php if (!defined('PmWiki')) exit();

$DefaultPasswords['edit'] = '';

############### Upload management ################
$EnableUpload = 1;
$UploadDir = "/home/groups/paradiseo/data/uploads";
$UploadUrlFmt = "";
$DefaultPasswords['upload'] = '';
$UploadPrefixFmt= '/$Group/$Name/';
# If 1, the uploaded are not overloaded by a time-suffix is set
$EnableUploadVersions= 1;

# Max uploads total size for the Upload group
$UploadPrefixQuota= 100000000; # 100MB 
# Global upload maximum size
$UploadDirQuota= 100000000; # 100MB
# Uploaded file maximum size
$UploadMaxSize= 25000000; # 25MB 

# Disable direct access to download dir
$EnableDirectDownload=0;

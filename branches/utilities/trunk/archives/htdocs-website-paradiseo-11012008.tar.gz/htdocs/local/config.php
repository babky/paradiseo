<?php $Skin = 'abitmodern';?>

<?php if (!defined('PmWiki')) exit();
$WikiTitle = "Paradiseo";
$PageLogoUrl = "../img/paradisEO_small.png";
$PageRedirectFmt = '';

# insert logo for all the pages
$HTMLHeaderFmt['logo'] = '<link href="http://paradiseo.gforge.inria.fr/img/ParadisEO_icone.ico"  rel="shortcut icon" />'; 

# Only the members of the "admins" group are authorized
$DefaultPasswords['admin'] = array('@admins');

# Only the members of the "admins" and "writers" group are authorized
$DefaultPasswords['edit'] = array('@admins','@writers');  

include_once("$FarmD/scripts/authuser.php");

include_once('cookbook/mailform2.php'); 
include_once('cookbook/pmwiki2pdf/pmwiki2pdf.php');
include_once('cookbook/imgpopup.php');
include_once('cookbook/popupwindow.php');
include_once('cookbook/enablehtml.php');

# enables a few html tags
EnableHtml('img|a|link');


$Mailform2Recipient='thomas.legrand@lifl.fr';
$Mailform2Sender='legrand@users.gforge.inria.fr';
$Mailform2Subject='[PARADISEO GFORGE WEBSITE] New user for ParadisEO !';
$Mailform2Text='Name: ' . $_POST['paradiseo-user']. "\n\n" . 'E-Mail: ' . $_POST['paradiseo-user-mail'] . "\n\n" . 'Organization: ' . $_POST['paradiseo-user-organization'] . "\n\n" . 'URL: ' . $_POST['paradiseo-user-url'] ;
$Mailform2SuccessPage='Paradiseo.DwnSC';
$Mailform2Disabled=0;


$EnableFontsizer = 0;
putenv("TZ=EST5EDT");
$TimeFmt = '%B %d, %Y, at %I:%M %p EST';

# Upload management
$EnableUpload = 0;
$EnableDirectDownload=0;
$DefaultPasswords['upload'] = '';

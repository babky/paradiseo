// 
// 2005-12-01  ksc  Initial release
//  

A port of 'A Bit Modern' on oswd.org by PickledSword / Boris Cherney
(http://oswd.org/design/information/id/2343). Well done.

If you don't like the site name and page name lowercased, replace 
$title with $WikiTitle and $currentpage with $Namespaced in 
abitmodern.tmpl. If you don't like the heavily styled hr tag there 
is a 1px grey hr commented out in the css file.

// Set $Skin to abitmodern in config.php
$Skin = 'abitmodern';

// Add to config.php and edit as needed
$SkinCopyright = '&copy; 2005 Your Site';

// Changing the menu in the menubar
Edit Site.PageActions or {GroupName}.PageActions (like Main.PageActions, etc). 

